package TeluguWords;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.regex.Pattern;

public class GenerateDictionary {
	public static void main(String[] args) throws Exception {
		File input = new File("files/re4");
		File input1 = new File("files/re5");
		String line = "";
		String line1 = "";
		
		
		BufferedReader br1 = new BufferedReader(new FileReader(input1));
		BufferedReader br = new BufferedReader(new FileReader(input));
		HashMap<String, String> phones=new HashMap<String, String>();
		PrintWriter out = new PrintWriter("files/op");

		while ((line = br.readLine()) != null){
			String str[]=line.trim().split(" ");
			phones.put(str[0], str[1]);
		}
		
		String mono="";
		while((line1 = br1.readLine()) != null){
			ArrayList<String> monoset=new ArrayList<String>();
			char ch[]=line1.toCharArray();
			for(int i=0;i<ch.length;i=i+mono.length()){

				boolean valid=false,flag=false;
				int j=i;
				String s=Character.toString(ch[i]);
				if(Pattern.matches("^\\d+$",s)){
					monoset.add(s);
					mono=s;
					flag=true;
				}
				while(phones.containsKey(s.toLowerCase())&&!flag)
				{	
					valid=true;
					mono=s;
					j++;
					if(j<ch.length)
					s=s.concat(Character.toString(ch[j]));
					else
						break;
					
				}
					if(valid||!flag)
					monoset.add(mono);
				
			
			}
			System.out.print(line1+"\t");
			for(String str:monoset){
				System.out.print(str+" ");
			}
			System.out.println();
		}
}
}
