package TeluguWords;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.ListIterator;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Transliterator {
	private static Scanner sc;
	private static FileInputStream fis;
	private static BufferedReader br;
	// private static ArrayList<String> letters;
	private static ArrayList<String> monoset;
	private static HashMap<String, String> letters;
	private static HashMap<String, String> hallsSet;
	private static ArrayList<String> words;
	private static HashSet<String> characterSet;
	private static ArrayList<String> inputLines;
	private static PrintWriter pw;
	private static StringBuffer sb;
	private static boolean first;

	public static void main(String[] args) {
		words = new ArrayList<String>();
		monoset = new ArrayList<String>();
		readDataFromFiles();
		/*
		 * //reading input data sc=new Scanner(System.in);
		 * System.out.println("Enter any word"); String text=sc.nextLine();
		 */
		String fileName = "Telugu_Result";
		try {
			pw = new PrintWriter(new FileWriter(fileName, true));
			for (String text : inputLines) {
				sb = new StringBuffer("");
				StringTokenizer stn = new StringTokenizer(text);
				while (stn.hasMoreTokens())
					words.add(stn.nextToken());
				char[] ch;
				for (String line : words) {
					// line=line.replaceAll("\\s", "");
					ch = line.toCharArray();
					String mono = null;
					for (int i = 0; i < ch.length; i = i + mono.length()) {
						boolean valid = false;
						int j = i;
						String s = Character.toString(ch[i]);
						while (characterSet.contains(s)) {
							valid = true;
							mono = s;
							j++;
							if (j < ch.length)
								s = s.concat(Character.toString(ch[j]));
							else
								break;
						}
						if (valid)
							monoset.add(mono);
					}
					translit();
					// System.out.print(" ");
					sb.append(" ");
					monoset.clear();
				}
				words.clear();
				// System.out.println(sb.toString());
				// System.out.println();

				pw.println(sb.toString());
			}
			pw.close();

		} catch (IOException e) {

			e.printStackTrace();
		}
	}

	private static void readDataFromFiles() {
		try {
			fis = new FileInputStream("letters.txt");
			br = new BufferedReader(new InputStreamReader(fis));
			letters = new HashMap<String, String>();
			String str;
			while ((str = br.readLine()) != null) {
				StringTokenizer st = new StringTokenizer(str);
				letters.put(st.nextToken(), st.nextToken());
			}
			fis = new FileInputStream("halls.txt");
			br = new BufferedReader(new InputStreamReader(fis));
			hallsSet = new HashMap<String, String>();
			String str1;
			while ((str1 = br.readLine()) != null) {
				StringTokenizer st = new StringTokenizer(str1);
				hallsSet.put(st.nextToken(), st.nextToken());
			}
			characterSet = new HashSet<String>();
			characterSet.addAll(letters.keySet());
			characterSet.addAll(hallsSet.keySet());
			inputLines = new ArrayList<String>();
			fis = new FileInputStream("telugu_trans");
			br = new BufferedReader(new InputStreamReader(fis));
			while ((str = br.readLine()) != null)
				inputLines.add(str);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}
	}

	private static void translit() {
		ListIterator<String> itr = monoset.listIterator();

		int i = 1;
		while (itr.hasNext()) {
			String s1 = itr.next();
			String s2 = null;

			if ((hallsSet.containsKey(s1) || s1.equals("a")) && i == 1) {
				first = true;
				// System.out.print(letters.get(s1));
				sb.append(letters.get(s1));
				// s1=s2;
				if (itr.hasNext()) {
					s1 = itr.next();
					// check(s2,ss,itr);
					if (hallsSet.containsKey(s1)) { // System.out.print(hallsSet.get(s1));
						sb.append(hallsSet.get(s1));
						if (itr.hasNext())
							s1 = itr.next();
					}
				} else
					s1 = null;
			} else if (hallsSet.containsKey(s1)) {
				// System.out.print(hallsSet.get(s1));
				sb.append(hallsSet.get(s1));
				// s1=s2;
				// s2=null;
				if (itr.hasNext())
					s1 = itr.next();
			} else
				first = false;
			if (itr.hasNext())
				s2 = itr.next();
			i++;
			check(s1, s2, itr);
			/*
			 * if(letters.containsKey(s1) && !halls){ letter=true; if(s2==null)
			 * System.out.println(letters.get(s1).concat(hallsSet.get("hal")));
			 * else if(hallsSet.containsKey(s2) || s2.equals("a"))
			 * System.out.print(letters.get(s1).concat(hallsSet.get(s2))); else
			 * { String temp=letters.get(s1).concat(letters.get(s2));
			 * check(temp,itr.next(),itr); } }
			 */

			/*
			 * if(hallsSet.containsKey(s) && letter) {
			 * result=result.concat(hallsSet.get(s)); System.out.print(result);
			 * 
			 * }else if(hallsSet.containsKey(s) && !letter) {
			 * 
			 * } else if(letters.containsKey(s)) { letter=true;
			 * result=letters.get(s); System.out.print(result); }
			 */
		}
	}

	private static void check(String s1, String s2, ListIterator<String> itr) {
		if (letters.containsKey(s1) && !hallsSet.containsKey(s1)) {
			if (s2 == null) {// System.out.print(letters.get(s1).concat(hallsSet.get("hal")));
				if (first)
					sb.append(letters.get(s1).concat(hallsSet.get("hal")));
			} else if (hallsSet.containsKey(s2) || s2.equals("a")) {
				if (!s2.equals("a")) {
					// System.out.print(letters.get(s1).concat(hallsSet.get(s2)));
					sb.append(letters.get(s1).concat(hallsSet.get(s2)));
				} else {
					// System.out.print(letters.get(s1));
					sb.append(letters.get(s1));
				}
			} else {
				String temp = letters.get(s1).concat(hallsSet.get("hal"));
				// System.out.print(temp);
				sb.append(temp);
				// String temp2=temp.concat(letters.get(s2));
				String t = null;
				if (itr.hasNext())
					t = itr.next();
				check(s2, t, itr);
				/*
				 * System.out.print(letters.get(s1)); check(s2,itr.next(),itr);
				 */
			}
		}

	}
}