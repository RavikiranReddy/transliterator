package TeluguWords;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.ListIterator;
import java.util.Scanner;
import java.util.Set;
import java.util.StringTokenizer;

public class trans7 {

	private static Scanner sc;
	private static FileInputStream fis;
	private static BufferedReader br;
	//private static ArrayList<String> letters;
	private static ArrayList<String> monoset;
	private static HashMap<String, String> letters;
	private static HashMap<String, String> hallsSet;
	private static ArrayList<String> words;
	private static HashSet<String> characterSet;
	private static ArrayList<String> inputLines;
	private static PrintWriter pw;
	private static StringBuffer sb;
	
	public static void main(String[] args) {

		words=new ArrayList<String>();
		monoset=new ArrayList<String>();
		readDataFromFiles();
		//reading input data
		sc=new Scanner(System.in);
		System.out.println("Enter any word");
		String text=sc.nextLine();
		
		String fileName = "Telugu_Result";
		try {
			pw=new PrintWriter(new FileWriter(fileName, true));
			
			
	/*for (String text : inputLines) 
	{*/
		sb=new StringBuffer("");
		StringTokenizer stn=new StringTokenizer(text);
		while(stn.hasMoreTokens())
			words.add(stn.nextToken());
							
		char[] ch;
		for (String line:words) {
			//line=line.replaceAll("\\s", "");
			ch=line.toCharArray();
			String mono = null;
			for (int i = 0; i < ch.length; i=i+mono.length()) 
			{
				boolean valid=false;
				int j=i;
				String s=Character.toString(ch[i]);
				
				while(characterSet.contains(s))
				{	
					valid=true;
					mono=s;
					j++;
					if(j<ch.length)
					s=s.concat(Character.toString(ch[j]));
					else
						break;
					
				}
				if(valid)
					monoset.add(mono);
			}
			/*for (String c : monoset) {
				System.out.println(c);
			}*/
			translit();
			System.out.print(" ");
			sb.append(" ");
			
			monoset.clear();
			}
			words.clear();
		//System.out.println(sb.toString());
			//System.out.println();
		
	//	pw.println(sb.toString());
	
		pw.close();
		
		} catch (IOException e) {
		
			e.printStackTrace();
		}
	}


	private static void readDataFromFiles() {
		try {
			fis=new FileInputStream("files/Tamil_Letters");
			br= new BufferedReader(new InputStreamReader(fis));
			letters=new HashMap<String,String>();
			String str;
			while((str=br.readLine())!=null)
			{
				StringTokenizer st=new StringTokenizer(str);
				letters.put(st.nextToken(),st.nextToken());
			}
		
		
			fis=new FileInputStream("files/Tamil_Halls");
			br= new BufferedReader(new InputStreamReader(fis));
			hallsSet=new HashMap<String,String>();
			String str1;
			while ((str1=br.readLine())!=null)
			{
				StringTokenizer st=new StringTokenizer(str1);
				hallsSet.put(st.nextToken(), st.nextToken());
			}
			
			characterSet = new HashSet<String>();
			
			characterSet.addAll(letters.keySet());
			characterSet.addAll(hallsSet.keySet());
			
			inputLines=new ArrayList<String>();
			fis=new FileInputStream("telugu_trans");
			br= new BufferedReader(new InputStreamReader(fis));		
			
			while((str=br.readLine())!=null)
				inputLines.add(str);
			
		
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
	}
	private static void translit() {
		
		/*//hallsSet map obj contains key,values of halls.txt
		//letters map obj contains key,values of letters.txt
		//monoset ArrayList contains monosets of input text
*/				ListIterator<String> itr= monoset.listIterator();
				
				int i=1;
				//Read mono set values from monoset list using iterator object 
				while(itr.hasNext())
				{
					String s1 = itr.next();
					String s2=null;
					//check s1 is 1st char & it is a vowel
												
					if((hallsSet.containsKey(s1) || s1.equals("a")) && i==1)
					{	/*
						//print s1 value from letters
						//read 2nd char, print hallsSet of 2nd char if it is vowel
						//if next char not available then set null value to s1
						*/System.out.print(letters.get(s1));
						sb.append(letters.get(s1));
						if(itr.hasNext())
						{	s1 = itr.next();
							if(hallsSet.containsKey(s1))
							{		System.out.print(hallsSet.get(s1));
							if(itr.hasNext())
								s1 = itr.next();
							}
						}else
							s1=null;
						
					}else if(hallsSet.containsKey(s1))
					{	//s1 is a vowel then print s1 value from hallsSet
						//read next element
							System.out.print(hallsSet.get(s1));
							sb.append(hallsSet.get(s1));
						if(itr.hasNext())
							s1 = itr.next();
					}
					
					if(itr.hasNext())
						s2 = itr.next();
					i++;
					//read 2nd char 
					//call check() by passing s1,s2,itr objects 
					check(s1,s2,itr);
					}
	}
	private static void check(String s1, String s2,ListIterator<String> itr) {
		//if s1 is a letter then this method will executes
		if(letters.containsKey(s1) && !hallsSet.containsKey(s1))
		{	//if s2 is null then 
			//  read s1 from letters map and "hal" key from hallsSet map
			//  concat above two values and print final value
			
			 
			if(s2==null)
			{	
					System.out.print(letters.get(s1).concat(hallsSet.get("hal")));
					sb.append(letters.get(s1).concat(hallsSet.get("hal")));
				
			}
			else if(hallsSet.containsKey(s2) || s2.equals("a"))
			{//if s2 is a vowel or contain "a"
				//print s1 value from letters if s2 contain "a"
				//concat s1 value from letters and s2 value from hallsSet
				//print above result value
				if(!s2.equals("a"))
				{
					System.out.print(letters.get(s1).concat(hallsSet.get(s2)));
					sb.append(letters.get(s1).concat(hallsSet.get(s2)));
				}
				else
				{
					System.out.print(letters.get(s1));
					sb.append(letters.get(s1));
				}	
			}
			else
			{	//above 2 conditions are not satisfied then
				//read s1 from letters map and "hal" key from hallsSet map
				//concat above two strings and print result value
				//read next char using iterator obj 
				//call check method by passing s2,next char,iterator object
				String temp=letters.get(s1).concat(hallsSet.get("hal"));
					System.out.print(temp);
					sb.append(temp);
					String t = null;
					if(itr.hasNext())
						t=itr.next();
					check(s2,t,itr);
				
			}
		}/*else if(hallsSet.containsKey(s1))
		{
			System.out.print(s1);
			sb.append(s1);
			String t = null;
			if(itr.hasNext())
				t=itr.next();
			check(s2,t,itr);
		}*/
		
	}


	
}